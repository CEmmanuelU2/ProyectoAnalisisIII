package examples;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class SugarDecorator implements Coffee {
    private final Coffee coffee;

    @Override
    public String getDescription() {
        return coffee.getDescription() + ", con azúcar";
    }

    @Override
    public double getCost() {
        return coffee.getCost() + 0.5;
    }
}