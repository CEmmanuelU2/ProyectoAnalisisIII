package examples;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class MilkDecorator implements Coffee {
    private final Coffee coffee;

    @Override
    public String getDescription() {
        return coffee.getDescription() + ", con leche";
    }

    @Override
    public double getCost() {
        return coffee.getCost() + 1.5;
    }
}