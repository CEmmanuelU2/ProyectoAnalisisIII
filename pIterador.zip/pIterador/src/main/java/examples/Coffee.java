package examples;

public interface Coffee {
}
