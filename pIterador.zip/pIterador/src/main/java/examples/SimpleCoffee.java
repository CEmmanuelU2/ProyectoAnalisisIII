package examples;

public class SimpleCoffee implements Coffee {

    @Override
    public String getDescription() {
        return "Café simple";
    }

    @Override
    public double getCost() {
        return 5.0;
    }
}